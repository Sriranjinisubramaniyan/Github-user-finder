
export interface GithubUser {
  login: string;
  id: number;
  avatar_url: string;
  html_url: string;
  name: string | null;
  company: string | null;
  blog: string | null;
  location: string | null;
  email: string | null;
  bio: string | null;
  twitter_username: string | null;
  public_repos: number;
  public_gists: number;
  followers: number;
  following: number;
  created_at: string;
}

export async function fetchGithubUser(username: string): Promise<GithubUser> {
  if (!username.trim()) {
    throw new Error("Please enter a username");
  }
  
  const response = await fetch(`https://api.github.com/users/${username}`);
  
  if (!response.ok) {
    if (response.status === 404) {
      throw new Error("User not found");
    }
    throw new Error("Error fetching user data");
  }
  
  return response.json();
}
